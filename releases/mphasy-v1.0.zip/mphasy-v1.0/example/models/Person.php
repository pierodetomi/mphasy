<?php
	class Person
	{
		public $Name;
		
		public $Age;
	}

// models/Person.php